import React, { useState } from 'react';
import {
  X,
  Menu,
  Search,
  Store,
  Building2,
  PlusCircle,
  FileSpreadsheet,
  Calculator,
  ShieldCheck,
  Percent,
  Bot,
  Headphones,
  Wallet,
  Settings,
  UserPlus,
  Lock,
  ArrowRight,
  Sparkles,
  ShoppingBag,
  Layers,
  Coins,
  FileText,
  UserCheck,
  CheckCircle2,
  RefreshCw,
  Sliders
} from 'lucide-react';
import { User, ProfitGuardConfig } from '../types';

export interface FunctionsDashboardDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onSelectTab: (tab: string) => void;
  onOpenProfitGuardModal: () => void;
  onOpenPoliciesModal: () => void;
  onOpenAIDispatch: () => void;
  onOpenStoreSyncModal: () => void;
  onOpenProductListing: () => void;
  onOpenBulkImport: () => void;
  onOpenHelplinesModal: () => void;
  onOpenWalletModal: () => void;
  onOpenProfileSettings: () => void;
  onOpenVerifiedRegistration: () => void;
  onOpenAdminAuth: () => void;
  isAdminAuthenticated: boolean;
  onLockAdmin: () => void;
  profitGuardConfig: ProfitGuardConfig;
  connectedStoresCount: number;
}

export const FunctionsDashboardDrawer: React.FC<FunctionsDashboardDrawerProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSelectTab,
  onOpenProfitGuardModal,
  onOpenPoliciesModal,
  onOpenAIDispatch,
  onOpenStoreSyncModal,
  onOpenProductListing,
  onOpenBulkImport,
  onOpenHelplinesModal,
  onOpenWalletModal,
  onOpenProfileSettings,
  onOpenVerifiedRegistration,
  onOpenAdminAuth,
  isAdminAuthenticated,
  onLockAdmin,
  profitGuardConfig,
  connectedStoresCount,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  // Execute an action and close the drawer
  const handleAction = (callback: () => void) => {
    callback();
    onClose();
  };

  const functionCategories = [
    {
      categoryName: 'Sourcing, Stores & Inventory',
      categoryBadge: 'Marketplace Tools',
      items: [
        {
          id: 'catalog',
          title: 'Wholesale Sourcing & Media Downloads',
          subtitle: 'Daraz-ready photos, factory prices, profit margins & one-click push',
          icon: Store,
          badge: 'Sourcing Hub',
          badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
          onClick: () => handleAction(() => onSelectTab('catalog')),
        },
        {
          id: 'stores-directory',
          title: 'Stores & Multi-Order Cart',
          subtitle: 'Browse Pakistani verified factory stores & bundle orders with single delivery',
          icon: Building2,
          badge: 'Flat Rs. 200 Delivery',
          badgeColor: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
          onClick: () => handleAction(() => onSelectTab('stores-directory')),
        },
        {
          id: 'list-product',
          title: '+ List New Wholesale Product',
          subtitle: 'Add product with multi-images, video, stock MOQ & wholesale specs',
          icon: PlusCircle,
          badge: 'Daraz Format',
          badgeColor: 'bg-teal-500/20 text-teal-400 border-teal-500/30',
          onClick: () => handleAction(onOpenProductListing),
        },
        {
          id: 'bulk-import',
          title: 'Bulk CSV / Excel Product Import',
          subtitle: 'Import hundreds of products at once with wholesale cost & SKU',
          icon: FileSpreadsheet,
          badge: 'Batch Upload',
          badgeColor: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
          onClick: () => handleAction(onOpenBulkImport),
        },
        {
          id: 'store-sync',
          title: 'Multi-Store Channel Sync',
          subtitle: 'Connect Shopify, Daraz, WooCommerce & TikTok Shop APIs',
          icon: RefreshCw,
          badge: `${connectedStoresCount} Connected`,
          badgeColor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
          onClick: () => handleAction(onOpenStoreSyncModal),
        },
        {
          id: 'checkout-demo',
          title: 'Storefront Buyer View (COD Simulation)',
          subtitle: 'Experience the direct customer checkout & COD booking flow',
          icon: ShoppingBag,
          badge: 'Retail View',
          badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
          onClick: () => handleAction(() => onSelectTab('checkout-demo')),
        },
      ],
    },
    {
      categoryName: 'Financial Tools & Protection Rules',
      categoryBadge: 'Profit & Risk Guard',
      items: [
        {
          id: 'profit-guard',
          title: 'Automated Profit Guard™ Settings',
          subtitle: `Protect profits against RTO delivery losses (Min Margin: PKR ${profitGuardConfig.minProfitAmountPKR})`,
          icon: ShieldCheck,
          badge: 'Active & Protecting',
          badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
          onClick: () => handleAction(onOpenProfitGuardModal),
        },
        {
          id: 'platform-policies',
          title: 'Software Policies (2% Commission Rules)',
          subtitle: 'Strict 2% software fee on delivered sales, 0% on returns, and escrow standards',
          icon: Percent,
          badge: '2% Fee Standard',
          badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
          onClick: () => handleAction(onOpenPoliciesModal),
        },
        {
          id: 'daraz-calculator',
          title: 'Daraz Fee & Tax Commission Calculator',
          subtitle: 'Simulate Daraz category commission, VAT, packaging & net courier profit',
          icon: Calculator,
          badge: 'FBR & Daraz 2026',
          badgeColor: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
          onClick: () => handleAction(() => onSelectTab('daraz-calculator')),
        },
        {
          id: 'wallet',
          title: 'Payout Wallet & Balance',
          subtitle: `Manage COD collections & withdrawals (Current: PKR ${currentUser.walletBalancePKR.toLocaleString()})`,
          icon: Wallet,
          badge: 'EasyPaisa / Bank',
          badgeColor: 'bg-teal-500/20 text-teal-400 border-teal-500/30',
          onClick: () => handleAction(onOpenWalletModal),
        },
      ],
    },
    {
      categoryName: 'AI Automation & Support Desks',
      categoryBadge: '24/7 Support Systems',
      items: [
        {
          id: 'ai-dispatch',
          title: 'AI Auto-Dispatch & Customer Reply Engine',
          subtitle: 'Automated AI responses for tracking, confirmation & parcel queries',
          icon: Bot,
          badge: 'AI Powered',
          badgeColor: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
          onClick: () => handleAction(onOpenAIDispatch),
        },
        {
          id: 'helplines',
          title: 'Platform Helplines & Support Desks',
          subtitle: 'Direct phone & WhatsApp contact for Retail Buyers, Resellers & Factories',
          icon: Headphones,
          badge: '3 Desks Live',
          badgeColor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
          onClick: () => handleAction(onOpenHelplinesModal),
        },
        {
          id: 'orders',
          title: 'Orders & Verification Hub',
          subtitle: 'Review pending orders, OTP verification, and Trax/PostEx courier manifests',
          icon: RefreshCw,
          badge: 'Live Operations',
          badgeColor: 'bg-slate-700 text-slate-200 border-slate-600',
          onClick: () => handleAction(() => onSelectTab('orders')),
        },
      ],
    },
    {
      categoryName: 'Account, Verification & Admin Security',
      categoryBadge: 'Identity & Access',
      items: [
        {
          id: 'profile-settings',
          title: 'Partner Profile & Settings',
          subtitle: 'Update Store Logo, CNIC, Father/Husband Name, Bank Account & NTN details',
          icon: Settings,
          badge: currentUser.role === 'SUPPLIER' ? 'Factory Profile' : 'Reseller Store',
          badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
          onClick: () => handleAction(onOpenProfileSettings),
        },
        {
          id: 'register-partner',
          title: 'Verified Partner Registration',
          subtitle: 'Join as a Dropshipper, Reseller Store, or Factory/Wholesale Manufacturer',
          icon: UserPlus,
          badge: 'Instant Signup',
          badgeColor: 'bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-300 border-emerald-400/40',
          onClick: () => handleAction(onOpenVerifiedRegistration),
        },
        ...(isAdminAuthenticated
          ? [
              {
                id: 'admin-hq',
                title: 'Master Platform Admin HQ',
                subtitle: 'Full access to bank config, user wallet balances, audit logs & security PIN',
                icon: Sliders,
                badge: 'Admin Session Active',
                badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/50',
                onClick: () => handleAction(() => onSelectTab('admin-hq')),
              },
              {
                id: 'admin-lock',
                title: 'Lock Admin Console',
                subtitle: 'Lock admin credentials and return to standard partner view',
                icon: Lock,
                badge: 'Security Lock',
                badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
                onClick: () => handleAction(onLockAdmin),
              },
            ]
          : [
              {
                id: 'admin-auth',
                title: 'System Administrator Gateway',
                subtitle: 'Enter master authentication key or PIN for enterprise administration',
                icon: Lock,
                badge: 'Protected',
                badgeColor: 'bg-slate-800 text-slate-400 border-slate-700',
                onClick: () => handleAction(onOpenAdminAuth),
              },
            ]),
      ],
    },
  ];

  // Filter items by search query
  const filteredCategories = functionCategories
    .map((cat) => ({
      ...cat,
      items: cat.items.filter(
        (item) =>
          item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.badge.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    }))
    .filter((cat) => cat.items.length > 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="relative flex flex-col w-full max-w-5xl h-[92vh] max-h-[850px] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/90">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 via-teal-600 to-indigo-700 text-white shadow-md">
              <Menu className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  Dashboard & All Functions
                </h2>
                <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-black uppercase text-emerald-400 border border-emerald-500/30">
                  Master Menu
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Top bar ke tamam functions aur enterprise tools yahan organized hain.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-xl bg-slate-800/80 text-slate-400 hover:bg-slate-700 hover:text-white transition"
            title="Close Dashboard"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Search & Active Persona Quick Strip */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-5 py-3 border-b border-slate-800/80 bg-slate-900/50">
          {/* Real-time Filter */}
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search functions (e.g. Daraz, Profit, AI, Wallet)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-950/80 pl-9 pr-4 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500/40"
            />
          </div>

          {/* Current User Pill */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <span className="text-[11px] text-slate-400">Current Persona:</span>
            <div className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/80 px-2.5 py-1 text-xs">
              <img
                src={currentUser.avatar || currentUser.logo}
                alt={currentUser.name}
                className="h-4 w-4 rounded-full object-cover"
              />
              <span className="font-bold text-white max-w-[120px] truncate">
                {currentUser.name}
              </span>
              <span className="rounded bg-emerald-950 px-1 py-0.2 text-[9px] font-bold text-emerald-400 border border-emerald-800">
                {currentUser.role}
              </span>
            </div>
          </div>
        </div>

        {/* Scrollable Functions Grid */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6 scrollbar-thin scrollbar-thumb-slate-700">
          {filteredCategories.length === 0 ? (
            <div className="text-center py-16">
              <Search className="mx-auto h-8 w-8 text-slate-600 mb-2" />
              <p className="text-sm font-semibold text-slate-300">Koi function nahi mila</p>
              <p className="text-xs text-slate-500 mt-1">
                Aap doosre lafz try karein jaise &quot;calculator&quot;, &quot;wallet&quot;, &quot;import&quot;, ya &quot;policy&quot;.
              </p>
            </div>
          ) : (
            filteredCategories.map((cat) => (
              <div key={cat.categoryName} className="space-y-3">
                {/* Category Header */}
                <div className="flex items-center justify-between pb-1 border-b border-slate-800/60">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-emerald-500" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      {cat.categoryName}
                    </h3>
                  </div>
                  <span className="text-[10px] font-semibold text-slate-500">
                    {cat.categoryBadge}
                  </span>
                </div>

                {/* Items Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {cat.items.map((item) => {
                    const ItemIcon = item.icon;
                    return (
                      <button
                        key={item.id}
                        onClick={item.onClick}
                        className="flex items-start gap-3 rounded-xl border border-slate-800 bg-slate-950/60 p-3.5 text-left transition hover:border-emerald-500/50 hover:bg-slate-800/60 hover:shadow-lg group cursor-pointer"
                      >
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-900 border border-slate-700 text-emerald-400 group-hover:border-emerald-500/60 group-hover:scale-105 transition">
                          <ItemIcon className="h-4.5 w-4.5" />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <h4 className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                              {item.title}
                            </h4>
                            <span
                              className={`shrink-0 rounded px-1.5 py-0.2 text-[9px] font-black uppercase border ${item.badgeColor}`}
                            >
                              {item.badge}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                            {item.subtitle}
                          </p>
                        </div>

                        <div className="self-center pl-1 text-slate-600 group-hover:text-emerald-400 group-hover:translate-x-0.5 transition">
                          <ArrowRight className="h-4 w-4" />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Quick Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 border-t border-slate-800 bg-slate-950 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-emerald-400 flex items-center gap-1">
              <Percent className="h-3 w-3" />
              <span>Platform Fee: 2% Flat</span>
            </span>
            <span className="text-slate-700">•</span>
            <span>Rs. 30 Processing</span>
            <span className="text-slate-700">•</span>
            <span>Automated Profit Guard™</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleAction(onOpenVerifiedRegistration)}
              className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-3 py-1.5 text-xs font-bold shadow transition"
            >
              <UserPlus className="h-3.5 w-3.5" />
              <span>Register Partner</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 text-xs font-bold transition"
            >
              Close Menu
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
