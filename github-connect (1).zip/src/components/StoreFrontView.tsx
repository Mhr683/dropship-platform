import React, { useState } from 'react';
import {
  Store as StoreIcon,
  ShieldCheck,
  Star,
  Truck,
  Clock,
  MapPin,
  Phone,
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  ArrowLeft,
  Eye,
  Heart,
  Sparkles,
  Package,
  Layers,
  ChevronRight,
  BadgePercent,
  Check,
  X,
} from 'lucide-react';
import { Product, Store, User, ProfitGuardConfig, BankTransferDetails } from '../types';

interface StoreFrontViewProps {
  store: Store;
  allProducts: Product[];
  currentUser: User;
  profitGuardConfig: ProfitGuardConfig;
  bankTransferDetails?: BankTransferDetails;
  onBack: () => void;
  onSelectProduct: (product: Product) => void;
  onPlaceMultiOrder: (
    items: { product: Product; quantity: number; sellingPrice: number }[],
    customerDetails: {
      customerName: string;
      customerPhone: string;
      customerCity: string;
      customerAddress: string;
    },
    totalAmountPKR: number
  ) => void;
}

export const StoreFrontView: React.FC<StoreFrontViewProps> = ({
  store,
  allProducts,
  currentUser,
  profitGuardConfig,
  bankTransferDetails,
  onBack,
  onSelectProduct,
  onPlaceMultiOrder,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');

  // Multi-Product Store Cart: Allows customer to add multiple products from this 1 store!
  const [cartItems, setCartItems] = useState<{ product: Product; quantity: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Customer Checkout Modal
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [customerName, setCustomerName] = useState(currentUser.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser.phone || '+92 300 1234567');
  const [customerCity, setCustomerCity] = useState(currentUser.city || 'Lahore');
  const [customerAddress, setCustomerAddress] = useState('Flat # 4, Main Commercial Boulevard');
  const [orderSuccessMessage, setOrderSuccessMessage] = useState<string | null>(null);

  // Filter products belonging to this specific store
  const storeProducts = allProducts.filter((p) => {
    // Check either storeId, supplierId, or supplierName
    const matchesStore =
      p.storeId === store.id ||
      p.supplierId === store.ownerId ||
      (p.supplierName && p.supplierName.toLowerCase().includes(store.name.toLowerCase())) ||
      (store.id === 'store-oshi' && (!p.storeId || p.supplierId === 'usr-1'));

    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCat = selectedCategory === 'ALL' || p.category === selectedCategory;

    return matchesStore && matchesSearch && matchesCat;
  });

  // Extract categories for this store
  const storeCategories = [
    'ALL',
    ...Array.from(
      new Set(
        allProducts
          .filter(
            (p) =>
              p.storeId === store.id ||
              p.supplierId === store.ownerId ||
              (store.id === 'store-oshi' && (!p.storeId || p.supplierId === 'usr-1'))
          )
          .map((p) => p.category)
      )
    ),
  ];

  // Cart operations
  const addToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as { product: Product; quantity: number }[]
    );
  };

  const removeFromCart = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Calculations
  const itemsSubtotal = cartItems.reduce(
    (sum, item) => sum + item.product.recSellingPricePKR * item.quantity,
    0
  );
  // Single consolidated shipping fee for ordering multiple items from 1 single store!
  const consolidatedShipping = cartItems.length > 0 ? profitGuardConfig.defaultShippingCostPKR || 250 : 0;
  const grandTotal = itemsSubtotal + consolidatedShipping;
  const totalItemsCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0) return;

    onPlaceMultiOrder(
      cartItems.map((item) => ({
        product: item.product,
        quantity: item.quantity,
        sellingPrice: item.product.recSellingPricePKR,
      })),
      {
        customerName,
        customerPhone,
        customerCity,
        customerAddress,
      },
      grandTotal
    );

    setIsCheckoutModalOpen(false);
    setCartItems([]);
    setOrderSuccessMessage(
      `🎉 Mubarak Ho! ${cartItems.length} Products ka combined store order COD dispatch ke liye place ho chuka hai.`
    );
    setTimeout(() => setOrderSuccessMessage(null), 6000);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-16">
      {/* Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 px-4 py-2 text-xs font-bold text-slate-200 transition"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Wapis Products Catalog par jayein</span>
        </button>

        {/* View Store Cart Floating Trigger */}
        <button
          onClick={() => setIsCartOpen(!isCartOpen)}
          className="flex items-center gap-2 rounded-xl bg-orange-600 hover:bg-orange-500 px-4 py-2 text-xs font-bold text-white shadow-lg transition relative"
        >
          <ShoppingCart className="h-4 w-4" />
          <span>Store Cart ({totalItemsCount} items)</span>
          {cartItems.length > 0 && (
            <span className="rounded-full bg-white px-2 py-0.2 text-[10px] font-black text-orange-600 font-mono">
              PKR {grandTotal.toLocaleString()}
            </span>
          )}
        </button>
      </div>

      {orderSuccessMessage && (
        <div className="rounded-2xl border border-emerald-500/40 bg-emerald-950/40 p-4 text-xs font-bold text-emerald-200 flex items-center gap-3 shadow-lg">
          <CheckCircle2 className="h-5 w-5 text-emerald-400 flex-shrink-0" />
          <span>{orderSuccessMessage}</span>
        </div>
      )}

      {/* =========================================================================
          STORE BANNER & OFFICIAL HEADER
      ========================================================================= */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-700 bg-slate-900 shadow-2xl">
        {/* Banner Image */}
        <div className="h-36 sm:h-48 w-full overflow-hidden relative">
          <img
            src={store.banner}
            alt={store.name}
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent" />
        </div>

        {/* Store Profile Info Bar */}
        <div className="relative px-6 pb-6 pt-0 -mt-12 sm:-mt-16 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex items-start sm:items-end gap-4">
            {/* Store Logo */}
            <div className="h-20 w-20 sm:h-24 sm:w-24 rounded-2xl border-4 border-slate-900 bg-slate-800 shadow-xl overflow-hidden flex-shrink-0">
              <img
                src={store.logo}
                alt={store.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Store Text Details */}
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-[10px] font-bold text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Verified {store.ownerRole === 'SUPPLIER' ? 'Manufacturer' : 'Reseller'}</span>
                </span>
                <span className="text-[11px] font-mono text-slate-400">ID: {store.verificationId}</span>
              </div>

              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                <span>{store.name}</span>
              </h1>

              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5 text-slate-400" />
                  <span>{store.city}</span>
                </span>
                <span>•</span>
                <span className="text-slate-300">
                  Operated by <strong className="text-white">{store.ownerName}</strong>
                </span>
                <span>•</span>
                <span className="text-slate-400">{store.category}</span>
              </div>
            </div>
          </div>

          {/* Store Metrics Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 md:pt-0">
            {/* Rating */}
            <div className="rounded-2xl border border-slate-800 bg-slate-950/80 px-3.5 py-2 text-center">
              <div className="flex items-center justify-center gap-1 text-amber-400 font-black text-sm">
                <Star className="h-3.5 w-3.5 fill-amber-400" />
                <span>{store.rating}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-semibold block">Store Rating</span>
            </div>

            {/* Delivery Rating */}
            <div className="rounded-2xl border border-slate-800 bg-slate-950/80 px-3.5 py-2 text-center">
              <div className="flex items-center justify-center gap-1 text-emerald-400 font-black text-xs">
                <Truck className="h-3.5 w-3.5" />
                <span>99% Fast</span>
              </div>
              <span className="text-[10px] text-slate-400 font-semibold block">On-Time Dispatch</span>
            </div>

            {/* Response Rate */}
            <div className="rounded-2xl border border-slate-800 bg-slate-950/80 px-3.5 py-2 text-center">
              <div className="flex items-center justify-center gap-1 text-blue-400 font-black text-xs">
                <Clock className="h-3.5 w-3.5" />
                <span>&lt; 15 mins</span>
              </div>
              <span className="text-[10px] text-slate-400 font-semibold block">Response Time</span>
            </div>

            {/* Total Orders */}
            <div className="rounded-2xl border border-slate-800 bg-slate-950/80 px-3.5 py-2 text-center">
              <div className="font-mono font-black text-white text-xs">
                {(store.totalOrders || 1200).toLocaleString()}+
              </div>
              <span className="text-[10px] text-slate-400 font-semibold block">Orders Shipped</span>
            </div>
          </div>
        </div>

        {/* Store Benefits Notice */}
        <div className="bg-gradient-to-r from-orange-950/60 via-slate-950 to-slate-950 border-t border-slate-800 px-6 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-orange-300 font-medium">
            <Sparkles className="h-4 w-4 text-orange-400 flex-shrink-0" />
            <span>
              <strong>Single Delivery Fee Guarantee:</strong> Is ek hi store se chahe 5 mukhtalif products mangwayein, courier charges sirf flat PKR 250 hi lagenge!
            </span>
          </div>
          <span className="rounded-full bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2.5 py-0.5 text-[10px] font-bold font-mono">
            Save PKR 750+ on Combined Shipping
          </span>
        </div>
      </div>

      {/* =========================================================================
          STORE PRODUCTS SECTION WITH SEARCH & CATEGORY
      ========================================================================= */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-black text-white">
              {store.name} ke Tamam Products ({storeProducts.length})
            </h2>
            <p className="text-xs text-slate-400">
              Is store ke items select karein aur aik sath 1 hi parcel mein COD deliver karwayein.
            </p>
          </div>

          {/* Search within store */}
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search in this store..."
              className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-9 pr-3.5 py-2 text-xs text-white placeholder-slate-500 focus:border-orange-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Categories Bar */}
        {storeCategories.length > 1 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {storeCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-lg px-3 py-1.5 text-xs font-bold transition whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                }`}
              >
                {cat === 'ALL' ? 'All Store Items' : cat}
              </button>
            ))}
          </div>
        )}

        {/* Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {storeProducts.map((p) => {
            const inCart = cartItems.find((i) => i.product.id === p.id);

            return (
              <div
                key={p.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-[0_2px_8px_rgba(0,0,0,0.04)] hover:shadow-lg transition-all duration-200 flex flex-col justify-between overflow-hidden group"
              >
                {/* Image Container */}
                <div
                  onClick={() => onSelectProduct(p)}
                  className="relative aspect-square w-full bg-slate-50/70 p-3 flex items-center justify-center overflow-hidden cursor-pointer"
                >
                  <img
                    src={p.image}
                    alt={p.name}
                    className="h-full w-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <span className="absolute bottom-2 left-2 bg-slate-900/80 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
                    Stock: {p.stock}
                  </span>
                </div>

                {/* Body */}
                <div className="p-3 flex flex-col flex-1 justify-between gap-2.5">
                  <div className="space-y-1">
                    <h3
                      onClick={() => onSelectProduct(p)}
                      className="text-slate-900 text-xs sm:text-[13px] font-semibold leading-snug line-clamp-2 hover:text-orange-600 cursor-pointer transition-colors"
                      title={p.name}
                    >
                      {p.name}
                    </h3>

                    {/* Ratings line under product */}
                    <div className="flex items-center gap-1.5 text-[11px] text-amber-600 font-semibold">
                      <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                      <span>{p.rating || 4.8}</span>
                      <span className="text-slate-400 font-normal">
                        ({p.reviewsCount || Math.floor((p.salesCount || 100) * 0.15)} reviews)
                      </span>
                    </div>
                  </div>

                  {/* Price & Add to Store Cart Button */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-medium">Selling Price</span>
                      <div className="text-slate-950 font-bold text-sm sm:text-base font-sans tracking-tight">
                        PKR {p.recSellingPricePKR.toLocaleString()}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => addToCart(p)}
                      className={`h-8 sm:h-9 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 transition shadow-sm cursor-pointer ${
                        inCart
                          ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                          : 'bg-[#e35614] text-white hover:bg-[#cf4a0e]'
                      }`}
                      title="Add to Store Multi-Order Cart"
                    >
                      {inCart ? (
                        <>
                          <Check className="h-3.5 w-3.5 stroke-[3]" />
                          <span>({inCart.quantity})</span>
                        </>
                      ) : (
                        <>
                          <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
                          <span>Add</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {storeProducts.length === 0 && (
          <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-12 text-center text-slate-400">
            <Package className="h-8 w-8 mx-auto mb-2 text-slate-600" />
            <p className="text-sm font-bold text-slate-200">No products found in this store category</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('ALL');
              }}
              className="mt-3 rounded-xl bg-orange-600 px-4 py-2 text-xs font-bold text-white hover:bg-orange-500"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* =========================================================================
          STORE CART DRAWER / SIDEBAR (MULTI-ORDER CAPABILITY)
      ========================================================================= */}
      {isCartOpen && (
        <div
          id="store-cart-modal-overlay"
          className="fixed inset-0 z-50 flex items-center justify-end bg-black/70 backdrop-blur-sm"
        >
          <div className="w-full max-w-md h-full bg-slate-900 border-l border-slate-800 flex flex-col justify-between shadow-2xl p-5 overflow-y-auto animate-fadeIn">
            {/* Header */}
            <div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
                    <ShoppingCart className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="text-base font-bold text-white">Store Order Cart</h3>
                    <span className="text-[11px] text-slate-400 font-medium">
                      Store: {store.name}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="rounded-full bg-slate-800 p-2 text-slate-400 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Notice */}
              <div className="mt-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 p-2.5 text-xs text-emerald-300 flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                <span>Single consolidated shipping (PKR 250) for all items in this store!</span>
              </div>

              {/* Items List */}
              <div className="mt-4 space-y-3 max-h-[50vh] overflow-y-auto pr-1">
                {cartItems.length === 0 ? (
                  <div className="py-12 text-center text-slate-500">
                    <ShoppingCart className="h-10 w-10 mx-auto mb-2 text-slate-700" />
                    <p className="text-sm">Aapka store cart khali hai.</p>
                    <p className="text-xs">Product cards par 'Add' click karein.</p>
                  </div>
                ) : (
                  cartItems.map((item) => (
                    <div
                      key={item.product.id}
                      className="rounded-2xl border border-slate-800 bg-slate-950 p-3 flex items-center gap-3"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="h-14 w-14 rounded-xl object-contain bg-white p-1 flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-semibold text-white truncate">
                          {item.product.name}
                        </h4>
                        <span className="text-xs font-mono font-bold text-orange-400 block">
                          PKR {item.product.recSellingPricePKR.toLocaleString()} × {item.quantity} = PKR{' '}
                          {(item.product.recSellingPricePKR * item.quantity).toLocaleString()}
                        </span>

                        {/* Quantity Controls */}
                        <div className="flex items-center gap-2 mt-1.5">
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.product.id, -1)}
                            className="h-6 w-6 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 flex items-center justify-center text-xs"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="font-mono text-xs font-bold text-white px-1">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.product.id, 1)}
                            className="h-6 w-6 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 flex items-center justify-center text-xs"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => removeFromCart(item.product.id)}
                        className="text-slate-500 hover:text-rose-400 p-1.5"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Bottom Checkout Details */}
            {cartItems.length > 0 && (
              <div className="border-t border-slate-800 pt-4 space-y-3">
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Products Subtotal ({totalItemsCount} items):</span>
                    <span className="font-mono text-slate-200">PKR {itemsSubtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-emerald-400">
                    <span>Store Consolidated Courier Delivery:</span>
                    <span className="font-mono">PKR {consolidatedShipping.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-base font-black text-white pt-2 border-t border-slate-800">
                    <span>Grand Total (COD):</span>
                    <span className="font-mono text-orange-400">PKR {grandTotal.toLocaleString()}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsCheckoutModalOpen(true)}
                  className="w-full rounded-2xl bg-orange-600 hover:bg-orange-500 text-white font-black py-3 text-xs tracking-wide transition shadow-xl shadow-orange-950 cursor-pointer flex items-center justify-center gap-2"
                >
                  <ShoppingCart className="h-4 w-4" />
                  <span>Order All {cartItems.length} Products Together (COD)</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MULTI-ORDER CHECKOUT MODAL
      ========================================================================= */}
      {isCheckoutModalOpen && (
        <div
          id="multi-order-checkout-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 overflow-y-auto"
        >
          <div className="relative w-full max-w-lg rounded-3xl border border-orange-500/40 bg-slate-900 text-slate-100 shadow-2xl p-5 sm:p-6 space-y-4 my-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">
                  Place Single Combined Store Order (COD)
                </h3>
                <span className="text-xs text-orange-400 font-semibold">Store: {store.name}</span>
              </div>
              <button
                onClick={() => setIsCheckoutModalOpen(false)}
                className="rounded-full bg-slate-800 p-2 text-slate-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCheckoutSubmit} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="font-semibold text-slate-300">Customer Full Name *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Asad Ullah Khan"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-white focus:border-orange-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-300">Mobile Number (COD) *</label>
                  <input
                    type="text"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="0300-1234567"
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-white font-mono focus:border-orange-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-300">Destination City *</label>
                  <input
                    type="text"
                    required
                    value={customerCity}
                    onChange={(e) => setCustomerCity(e.target.value)}
                    placeholder="Karachi / Lahore / Islamabad"
                    className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-white focus:border-orange-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-300">Complete Delivery Address *</label>
                <textarea
                  rows={2}
                  required
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  placeholder="House #, Street #, Sector, Landmark"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-white focus:border-orange-500 focus:outline-none resize-none"
                />
              </div>

              {/* Order Summary box */}
              <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 space-y-1.5">
                <div className="flex justify-between text-slate-400">
                  <span>Selected Products:</span>
                  <span className="font-bold text-white">{cartItems.length} items ({totalItemsCount} units)</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Consolidated Delivery:</span>
                  <span className="text-emerald-400 font-bold">PKR {consolidatedShipping} (Flat)</span>
                </div>
                <div className="flex justify-between text-sm font-black text-white pt-1.5 border-t border-slate-800">
                  <span>Pay on Cash on Delivery:</span>
                  <span className="text-orange-400 font-mono">PKR {grandTotal.toLocaleString()}</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full rounded-2xl bg-orange-600 hover:bg-orange-500 text-white font-black py-3 text-xs tracking-wide transition shadow-xl cursor-pointer"
              >
                Confirm & Dispatch Multi-Order Parcel
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
