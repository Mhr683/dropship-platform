import React, { useState } from 'react';
import {
  LayoutDashboard,
  Store,
  Building2,
  Calculator,
  RefreshCw,
  ShoppingBag,
  Truck,
  Wallet,
  Headphones,
  Lock,
  Shield,
  ShieldCheck,
  Bot,
  Link,
  Plus,
  FileSpreadsheet,
  FileText,
  ArrowRightLeft,
  Crown,
  Menu,
  X,
  ChevronRight,
} from 'lucide-react';
import { User } from '../types';

interface YourMartSidebarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  pendingOrdersCount?: number;
  cartCount?: number;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
  currentUser: User;
  isAdminAuthenticated?: boolean;
  onOpenFunctionsDrawer: () => void;
  onOpenUpgradeModal: () => void;
  onOpenStoreSyncModal: () => void;
  onOpenWalletModal: () => void;
  onOpenCart: () => void;
  onOpenHelplinesModal: () => void;
  onOpenAdminAuth?: () => void;
  onLockAdmin?: () => void;
  onOpenProfitGuardModal?: () => void;
  onOpenAIDispatch?: () => void;
  onOpenProductListing?: () => void;
  onOpenBulkImport?: () => void;
  onOpenPoliciesModal?: () => void;
}

export const YourMartSidebar: React.FC<YourMartSidebarProps> = ({
  activeTab,
  onSelectTab,
  pendingOrdersCount = 7,
  cartCount = 1,
  isOpenMobile = false,
  onCloseMobile,
  currentUser,
  isAdminAuthenticated = false,
  onOpenFunctionsDrawer,
  onOpenUpgradeModal,
  onOpenStoreSyncModal,
  onOpenWalletModal,
  onOpenCart,
  onOpenHelplinesModal,
  onOpenAdminAuth,
  onLockAdmin,
  onOpenProfitGuardModal,
  onOpenAIDispatch,
  onOpenProductListing,
  onOpenBulkImport,
  onOpenPoliciesModal,
}) => {
  const [b2cMode, setB2cMode] = useState(false);
  const [isToolsExpanded, setIsToolsExpanded] = useState(true);

  const handleAction = (callback: () => void) => {
    callback();
    if (onCloseMobile) onCloseMobile();
  };

  const sidebarContent = (
    <div className="flex h-full flex-col justify-between bg-[#080D1A] text-slate-200 border-r border-slate-800/90 w-64 select-none">
      {/* Scrollable Main Section */}
      <div className="flex-1 overflow-y-auto px-3.5 py-4 space-y-3.5 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
        {/* 1. BRAND LOGO & BADGE (Enterprise Wholesale & B2B) */}
        <div className="flex items-center justify-between pb-1">
          <div
            onClick={() => handleAction(() => onSelectTab('dashboard'))}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 text-white font-black text-sm shadow-md shadow-emerald-900/30 group-hover:scale-105 transition">
              YM
            </div>
            <div>
              <div className="text-sm font-black tracking-tight text-white flex items-center gap-1.5">
                <span>Yourmart</span>
                <span className="text-emerald-400">Global</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="inline-block rounded bg-emerald-950/90 border border-emerald-500/40 px-1.5 py-0.2 text-[8px] font-black text-emerald-400 uppercase tracking-wider">
                  ENTERPRISE
                </span>
                <span className="text-[9px] text-slate-400 font-medium truncate max-w-[80px]">
                  Wholesale & B2B
                </span>
              </div>
            </div>
          </div>

          {/* Close button on mobile */}
          {isOpenMobile && onCloseMobile && (
            <button
              onClick={onCloseMobile}
              className="lg:hidden p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* 2. Switch to B2C Dropshipping Button */}
        <button
          onClick={() => setB2cMode(!b2cMode)}
          className="w-full flex items-center justify-center gap-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/60 py-2 px-3 text-xs font-semibold text-slate-300 hover:text-white transition shadow-xs"
        >
          <ArrowRightLeft className="h-3.5 w-3.5 text-emerald-400" />
          <span className="truncate">{b2cMode ? 'Switch to: Wholesale B2B' : 'Switch to: B2C Dropshipping'}</span>
        </button>

        {/* 3. "Dashboard & Functions [ALL TOOLS]" Gradient Button (From Wholesale Sourcing page) */}
        <button
          onClick={() => handleAction(onOpenFunctionsDrawer)}
          className="w-full flex items-center justify-between rounded-xl bg-gradient-to-r from-teal-500 via-emerald-600 to-cyan-600 hover:from-teal-400 hover:to-cyan-500 text-white font-extrabold px-3 py-2.5 shadow-md shadow-emerald-950/40 transition group cursor-pointer"
        >
          <div className="flex items-center gap-2 text-left">
            <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-white/20 text-white">
              <Menu className="h-3.5 w-3.5" />
            </div>
            <div className="leading-tight">
              <div className="text-xs font-black">Dashboard & Functions</div>
              <div className="text-[9px] text-emerald-100 font-medium">All Sourcing & Management Tools</div>
            </div>
          </div>
          <span className="rounded-md bg-white/20 px-1.5 py-0.5 text-[9px] font-black uppercase text-white tracking-wider">
            ALL TOOLS
          </span>
        </button>

        {/* 4. MAIN CORE NAVIGATION (Wholesale Sourcing Page Functions) */}
        <div className="space-y-1 pt-1">
          <div className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider px-2 pb-1">
            Core Portals
          </div>

          {/* Dashboard (Front Page) */}
          <button
            onClick={() => handleAction(() => onSelectTab('dashboard'))}
            className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-xs font-bold transition text-left ${
              activeTab === 'dashboard'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/30'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <LayoutDashboard className={`h-4 w-4 ${activeTab === 'dashboard' ? 'text-white' : 'text-emerald-400'}`} />
              <span>Dashboard (Front Page)</span>
            </div>
          </button>

          {/* Wholesale Sourcing & Media Downloads */}
          <button
            onClick={() => handleAction(() => onSelectTab('catalog'))}
            className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-xs font-bold transition text-left ${
              activeTab === 'catalog'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/30'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <Store className={`h-4 w-4 shrink-0 ${activeTab === 'catalog' ? 'text-white' : 'text-emerald-400'}`} />
              <span className="truncate">Wholesale Sourcing & Media</span>
            </div>
          </button>

          {/* Stores Directory (Multi-Order Cart) */}
          <button
            onClick={() => handleAction(() => onSelectTab('stores-directory'))}
            className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-xs font-bold transition text-left ${
              activeTab === 'stores-directory'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950/30'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <Building2 className={`h-4 w-4 shrink-0 ${activeTab === 'stores-directory' ? 'text-white' : 'text-indigo-400'}`} />
              <span className="truncate">Stores Directory (Multi-Order)</span>
            </div>
          </button>

          {/* Daraz Fee & Tax Calculator */}
          <button
            onClick={() => handleAction(() => onSelectTab('daraz-calculator'))}
            className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-xs font-bold transition text-left ${
              activeTab === 'daraz-calculator'
                ? 'bg-orange-600 text-white shadow-md shadow-orange-950/30'
                : 'text-orange-300/90 hover:bg-slate-800/80 hover:text-orange-200'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <Calculator className={`h-4 w-4 shrink-0 ${activeTab === 'daraz-calculator' ? 'text-white' : 'text-orange-400'}`} />
              <span className="truncate">Daraz Fee & Tax Calculator</span>
            </div>
          </button>

          {/* Orders & Verification */}
          <button
            onClick={() => handleAction(() => onSelectTab('orders'))}
            className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-xs font-bold transition text-left ${
              activeTab === 'orders'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/30'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <RefreshCw className={`h-4 w-4 shrink-0 ${activeTab === 'orders' ? 'text-white' : 'text-emerald-400'}`} />
              <span className="truncate">Orders & Verification</span>
            </div>
            {pendingOrdersCount > 0 && (
              <span className="shrink-0 flex h-5 w-5 items-center justify-center rounded-full bg-amber-500 text-[10px] font-black text-slate-950">
                {pendingOrdersCount}
              </span>
            )}
          </button>

          {/* SmartSend Pk / Storefront Retail Demo View (COD) */}
          <button
            onClick={() => handleAction(() => onSelectTab('checkout-demo'))}
            className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-xs font-bold transition text-left ${
              activeTab === 'checkout-demo'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-950/30'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <Truck className={`h-4 w-4 shrink-0 ${activeTab === 'checkout-demo' ? 'text-white' : 'text-blue-400'}`} />
              <span className="truncate">Storefront View (COD)</span>
            </div>
          </button>
        </div>

        {/* 5. SOURCING PAGE QUICK TOOLS (Wallet, Cart, Helplines, Admin Gateway) */}
        <div className="space-y-1.5 pt-2 border-t border-slate-800/70">
          <div className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider px-2 pb-0.5">
            Finance & Services
          </div>

          {/* Wallet Balance Widget */}
          <button
            onClick={() => handleAction(onOpenWalletModal)}
            className="w-full flex items-center justify-between rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/60 p-2.5 text-xs font-semibold text-slate-200 transition group cursor-pointer"
          >
            <div className="flex items-center gap-2 min-w-0">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-emerald-500/20 text-emerald-400 group-hover:scale-105 transition">
                <Wallet className="h-4 w-4" />
              </div>
              <div className="text-left min-w-0 leading-tight">
                <div className="text-[10px] text-slate-400 font-medium">Wallet & Payouts</div>
                <div className="text-xs font-bold text-emerald-400 font-mono">
                  PKR {currentUser.walletBalancePKR ? currentUser.walletBalancePKR.toLocaleString() : '84,500'}
                </div>
              </div>
            </div>
            <span className="text-[10px] font-bold text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
              View
            </span>
          </button>

          {/* Cart with count */}
          <button
            onClick={() => handleAction(onOpenCart)}
            className="w-full flex items-center justify-between rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/60 p-2.5 text-xs font-semibold text-slate-200 transition group cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-teal-500/20 text-teal-400">
                <ShoppingBag className="h-4 w-4" />
              </div>
              <div className="text-left leading-tight">
                <div className="text-xs font-bold text-white">Consolidated Cart</div>
                <div className="text-[10px] text-slate-400">Weight-based Delivery</div>
              </div>
            </div>
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-slate-950 font-black text-[10px]">
              {cartCount > 0 ? cartCount : 1}
            </span>
          </button>

          {/* Helplines Quick Access */}
          <button
            onClick={() => handleAction(onOpenHelplinesModal)}
            className="w-full flex items-center justify-between rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/60 p-2.5 text-xs font-semibold text-slate-200 transition group cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-blue-500/20 text-blue-400">
                <Headphones className="h-4 w-4" />
              </div>
              <div className="text-left leading-tight">
                <div className="text-xs font-bold text-white">Helplines & Support</div>
                <div className="text-[10px] text-slate-400">Live Supplier/Buyer Help</div>
              </div>
            </div>
            <span className="text-[10px] text-emerald-400 font-bold">24/7</span>
          </button>

          {/* Admin Gateway Access */}
          {isAdminAuthenticated ? (
            <div className="flex items-center justify-between rounded-xl border border-purple-500/50 bg-purple-950/40 p-2">
              <button
                onClick={() => handleAction(() => onSelectTab('admin-hq'))}
                className="flex items-center gap-2 text-xs font-bold text-purple-200"
              >
                <Shield className="h-4 w-4 text-purple-400" />
                <span>Admin HQ Control</span>
              </button>
              {onLockAdmin && (
                <button
                  onClick={onLockAdmin}
                  className="rounded bg-purple-900/80 hover:bg-rose-600 p-1 text-purple-200 text-xs transition"
                  title="Lock Admin"
                >
                  <Lock className="h-3 w-3" />
                </button>
              )}
            </div>
          ) : (
            onOpenAdminAuth && (
              <button
                onClick={() => handleAction(onOpenAdminAuth)}
                className="w-full flex items-center justify-between rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 p-2 text-xs text-slate-400 hover:text-slate-200 transition"
              >
                <div className="flex items-center gap-2">
                  <Lock className="h-3.5 w-3.5 text-slate-500" />
                  <span>Admin Gateway Access</span>
                </div>
                <span className="text-[10px] text-slate-500">Locked</span>
              </button>
            )
          )}
        </div>

        {/* 6. ADVANCED UTILITIES & OPERATIONS */}
        <div className="space-y-1 pt-2 border-t border-slate-800/70">
          <div className="flex items-center justify-between px-2 pb-0.5">
            <span className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider">
              Operations
            </span>
            <button
              onClick={() => setIsToolsExpanded(!isToolsExpanded)}
              className="text-[10px] text-emerald-400 hover:underline cursor-pointer"
            >
              {isToolsExpanded ? 'Hide' : 'Show'}
            </button>
          </div>

          {isToolsExpanded && (
            <div className="space-y-1">
              {/* Store Sync & Auto-Fulfillment */}
              <button
                onClick={() => handleAction(onOpenStoreSyncModal)}
                className="w-full flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white transition text-left"
              >
                <Link className="h-3.5 w-3.5 text-orange-400" />
                <span>Connect Stores & Shopify</span>
              </button>

              {/* Profit Guard Engine */}
              {onOpenProfitGuardModal && (
                <button
                  onClick={() => handleAction(onOpenProfitGuardModal)}
                  className="w-full flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white transition text-left"
                >
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Profit Guard Engine</span>
                </button>
              )}

              {/* AI Dispatch & Rider Assignment */}
              {onOpenAIDispatch && (
                <button
                  onClick={() => handleAction(onOpenAIDispatch)}
                  className="w-full flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white transition text-left"
                >
                  <Bot className="h-3.5 w-3.5 text-cyan-400" />
                  <span>AI Rider Dispatching</span>
                </button>
              )}

              {/* Add New Product Listing */}
              {onOpenProductListing && (
                <button
                  onClick={() => handleAction(onOpenProductListing)}
                  className="w-full flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white transition text-left"
                >
                  <Plus className="h-3.5 w-3.5 text-emerald-400" />
                  <span>+ Add Product Listing</span>
                </button>
              )}

              {/* Bulk Excel/CSV Import */}
              {onOpenBulkImport && (
                <button
                  onClick={() => handleAction(onOpenBulkImport)}
                  className="w-full flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white transition text-left"
                >
                  <FileSpreadsheet className="h-3.5 w-3.5 text-purple-400" />
                  <span>Bulk Excel Import</span>
                </button>
              )}

              {/* Platform Rules & Reseller Policies */}
              {onOpenPoliciesModal && (
                <button
                  onClick={() => handleAction(onOpenPoliciesModal)}
                  className="w-full flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 hover:text-white transition text-left"
                >
                  <FileText className="h-3.5 w-3.5 text-blue-400" />
                  <span>Platform Policies & SOPs</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Upgrade Your Plan Card (Exact match with screenshot) */}
      <div className="p-3 border-t border-slate-800/90 bg-[#060913]">
        <div className="rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950 p-3 border border-slate-800/90 shadow-lg space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
            <Crown className="h-3.5 w-3.5 text-amber-400" />
            <span>Upgrade Your Plan</span>
          </div>
          <p className="text-[10px] text-slate-400 leading-relaxed">
            Get premium access to all downloads & features.
          </p>
          <button
            onClick={() => handleAction(onOpenUpgradeModal)}
            className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-1.5 shadow-md shadow-emerald-950/30 transition cursor-pointer"
          >
            <span>Upgrade Now</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar (Fixed on left) */}
      <aside className="hidden lg:block fixed inset-y-0 left-0 z-30 w-64 shadow-xl">
        {sidebarContent}
      </aside>

      {/* Mobile Sidebar (Slide-over drawer) */}
      {isOpenMobile && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />
          <div className="relative flex w-64 max-w-xs flex-1 flex-col bg-[#080D1A] z-10">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
