import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { MultiProductCartDrawer, CartItem } from './components/MultiProductCartDrawer';
import { AdminDashboard } from './components/AdminDashboard';
import { SupplierPortal } from './components/SupplierPortal';
import { ResellerPortal } from './components/ResellerPortal';
import { OrdersManager } from './components/OrdersManager';
import { ProfitGuardModal } from './components/ProfitGuardModal';
import { StoreSyncModal } from './components/StoreSyncModal';
import { CustomerCheckoutView } from './components/CustomerCheckoutView';
import { WalletModal } from './components/WalletModal';
import { AdminAuthModal } from './components/AdminAuthModal';
import { HelplinesModal } from './components/HelplinesModal';
import { DarazCalculator } from './components/DarazCalculator';
import { VerifiedRegistrationModal } from './components/VerifiedRegistrationModal';
import { ProductListingModal } from './components/ProductListingModal';
import { StoreFrontView } from './components/StoreFrontView';
import { StoresDirectoryView } from './components/StoresDirectoryView';
import { FrontPageDashboard } from './components/FrontPageDashboard';
import { YourMartSidebar } from './components/YourMartSidebar';
import { YourMartTopBar } from './components/YourMartTopBar';
import { BulkImportModal } from './components/BulkImportModal';
import { ProfileSettingsModal } from './components/ProfileSettingsModal';
import { PlatformPoliciesModal } from './components/PlatformPoliciesModal';
import { AIDispatchModal } from './components/AIDispatchModal';
import { FunctionsDashboardDrawer } from './components/FunctionsDashboardDrawer';
import { RegistrationRequiredModal } from './components/RegistrationRequiredModal';
import { initialStores } from './data/storesData';
import {
  initialProfitGuardConfig,
  initialUsers,
  initialProducts,
  initialOrders,
  initialStoreIntegrations,
  initialTransactions,
  initialBankTransferDetails,
  initialAdminSecurityConfig,
  initialAdminAuditLogs,
  initialPlatformHelplinesConfig,
} from './data/initialData';
import {
  User,
  Product,
  Order,
  ProfitGuardConfig,
  StoreIntegration,
  WalletTransaction,
  ChatMessage,
  BankTransferDetails,
  AdminSecurityConfig,
  AdminAuditLog,
  PlatformHelplinesConfig,
  Store,
  VerifiedRegistrationData,
} from './types';
import { evaluateOrderFinancials } from './utils/profitGuard';

export default function App() {
  // Global Application State
  const [profitGuardConfig, setProfitGuardConfig] = useState<ProfitGuardConfig>(initialProfitGuardConfig);
  const [bankTransferDetails, setBankTransferDetails] = useState<BankTransferDetails>(() => {
    const saved = localStorage.getItem('ym_bank_transfer_details');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return initialBankTransferDetails;
  });

  const [helplinesConfig, setHelplinesConfig] = useState<PlatformHelplinesConfig>(() => {
    const saved = localStorage.getItem('ym_helplines_config');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return initialPlatformHelplinesConfig;
  });

  // Security & Admin Session Management
  const [securityConfig, setSecurityConfig] = useState<AdminSecurityConfig>(() => {
    const saved = localStorage.getItem('ym_admin_security_config');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return initialAdminSecurityConfig;
  });

  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>(() => {
    const saved = localStorage.getItem('ym_admin_audit_logs');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return initialAdminAuditLogs;
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('ym_admin_auth') === 'true';
  });
  const [isAdminAuthModalOpen, setIsAdminAuthModalOpen] = useState<boolean>(false);

  // Users & Sourcing State - Default to Reseller (Ali Raza / Zainab) so Admin is isolated
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [currentUser, setCurrentUser] = useState<User>(() => {
    return isAdminAuthenticated ? initialUsers[0] : initialUsers[2];
  });
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [stores, setStores] = useState<StoreIntegration[]>(initialStoreIntegrations);
  const [transactions, setTransactions] = useState<WalletTransaction[]>(initialTransactions);

  // Verified Stores State (Manufacturers & Reseller Stores)
  const [allStores, setAllStores] = useState<Store[]>(() => {
    const saved = localStorage.getItem('ym_all_stores');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return initialStores;
  });
  const [selectedStoreForView, setSelectedStoreForView] = useState<Store | null>(null);

  // Navigation State - Default to Front Page Dashboard (matching screenshot)
  const [activeTab, setActiveTab] = useState<string>(() => {
    return isAdminAuthenticated ? 'admin-hq' : 'dashboard';
  });

  // Consolidated Multi-Item Cart for Single Store / Consolidated Delivery by Weight
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('ym_multi_cart_items');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [];
  });
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('ym_multi_cart_items', JSON.stringify(cartItems));
  }, [cartItems]);

  const handleAddToCart = (product: Product, quantity = 1, variant?: string) => {
    setCartItems((prev) => {
      // Check if adding from a different store:
      if (prev.length > 0) {
        const existingStore = prev[0].product.supplierId || prev[0].product.storeId;
        const newStore = product.supplierId || product.storeId;
        if (existingStore && newStore && existingStore !== newStore) {
          const confirmSwitch = window.confirm(
            `Aap ke cart me pehle se doosre store ki cheezyn hain. Pakistan me delivery fees aik parcel k wazan (weight) k hisaab se lagti hy.\n\nKia aap is naye store ka naya parcel shuru krna chahtay hain?`
          );
          if (confirmSwitch) {
            return [{ product, quantity, selectedVariant: variant }];
          } else {
            return prev;
          }
        }
      }

      const existingIndex = prev.findIndex((item) => item.product.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + quantity,
        };
        return updated;
      } else {
        return [...prev, { product, quantity, selectedVariant: variant }];
      }
    });
    setIsCartDrawerOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Modals & Drawers
  const [isFunctionsDrawerOpen, setIsFunctionsDrawerOpen] = useState(false);
  const [isRegistrationRequiredModalOpen, setIsRegistrationRequiredModalOpen] = useState(false);
  const [isProfitGuardModalOpen, setIsProfitGuardModalOpen] = useState(false);
  const [isStoreSyncModalOpen, setIsStoreSyncModalOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isHelplinesModalOpen, setIsHelplinesModalOpen] = useState(false);
  const [isVerifiedRegistrationOpen, setIsVerifiedRegistrationOpen] = useState(false);
  const [isProductListingOpen, setIsProductListingOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);
  const [isProfileSettingsOpen, setIsProfileSettingsOpen] = useState(false);
  const [isPoliciesModalOpen, setIsPoliciesModalOpen] = useState(false);
  const [isAIDispatchModalOpen, setIsAIDispatchModalOpen] = useState(false);

  // Pending orders waiting for guest registration
  const [pendingSingleOrder, setPendingSingleOrder] = useState<{
    product: Product;
    sellingPrice: number;
    customerName: string;
    customerPhone?: string;
    customerCity?: string;
    customerAddress?: string;
  } | null>(null);

  const [pendingMultiOrder, setPendingMultiOrder] = useState<{
    store: any;
    items: { product: Product; quantity: number }[];
    totalAmount: number;
    customerDetails: {
      customerName: string;
      customerPhone: string;
      customerCity: string;
      customerAddress: string;
    };
    deliveryCharges?: number;
    totalWeightKg?: number;
  } | null>(null);

  // Check if active user is registered (not guest)
  const isRegisteredUser = (user: User): boolean => {
    if (user.role === 'GUEST') return false;
    if (user.isRegistered === false) return false;
    return true;
  };

  const handleUpdateUserProfile = (updated: Partial<User>) => {
    const updatedUser: User = { ...currentUser, ...updated };
    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
    handleLogAudit(
      'USER_PROFILE_UPDATED',
      `Updated profile & settings for ${updatedUser.name} (${updatedUser.role})`,
      'SUCCESS'
    );
  };

  // Persist allStores
  useEffect(() => {
    localStorage.setItem('ym_all_stores', JSON.stringify(allStores));
  }, [allStores]);

  // Global Keyboard shortcut listener for Software Creator Admin access (Alt + A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.altKey && e.key.toLowerCase() === 'a') || (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'a')) {
        e.preventDefault();
        setIsAdminAuthModalOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Audit Logger Helper
  const handleLogAudit = (
    action: string,
    details: string,
    status: 'SUCCESS' | 'WARNING' | 'FAILED'
  ) => {
    const newLog: AdminAuditLog = {
      id: `log-${Date.now()}`,
      action,
      details,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      ip: '110.39.42.18 (Lahore PK)',
      status,
      adminUser: currentUser.role === 'ADMIN' ? currentUser.name : 'Master Administrator',
    };
    setAuditLogs((prev) => {
      const updated = [newLog, ...prev];
      localStorage.setItem('ym_admin_audit_logs', JSON.stringify(updated));
      return updated;
    });
  };

  // Admin Authentication Success
  const handleAuthenticateAdminSuccess = () => {
    setIsAdminAuthenticated(true);
    sessionStorage.setItem('ym_admin_auth', 'true');
    const adminUser = users.find((u) => u.role === 'ADMIN') || users[0];
    setCurrentUser(adminUser);
    setActiveTab('admin-hq');
    setIsAdminAuthModalOpen(false);
  };

  // Admin Lock / Logout
  const handleLockAdmin = () => {
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem('ym_admin_auth');
    const resellerUser = users.find((u) => u.role === 'RESELLER') || users[2];
    setCurrentUser(resellerUser);
    setActiveTab('catalog');
    handleLogAudit('ADMIN_CONSOLE_LOCKED', 'Master Admin session closed and locked', 'SUCCESS');
  };

  // Update Security Config
  const handleUpdateSecurityConfig = (newSec: AdminSecurityConfig) => {
    setSecurityConfig(newSec);
    localStorage.setItem('ym_admin_security_config', JSON.stringify(newSec));
  };

  // Update Helplines Config (Buyers, Resellers, Manufacturers)
  const handleUpdateHelplinesConfig = (newHelplines: PlatformHelplinesConfig) => {
    setHelplinesConfig(newHelplines);
    localStorage.setItem('ym_helplines_config', JSON.stringify(newHelplines));
  };

  // Global Handlers
  const handleSelectUser = (user: User) => {
    if (user.role === 'ADMIN' && !isAdminAuthenticated) {
      setIsAdminAuthModalOpen(true);
      return;
    }

    setCurrentUser(user);
    if (user.role === 'ADMIN') {
      setActiveTab('admin-hq');
    } else if (user.role === 'SUPPLIER') {
      setActiveTab('supplier-hub');
    } else if (user.role === 'RESELLER') {
      setActiveTab('catalog');
    }
  };

  // Handle Tab Selection with Protected Route Guard
  const handleSelectTab = (tab: string) => {
    if (tab === 'admin-hq' && !isAdminAuthenticated) {
      setIsAdminAuthModalOpen(true);
      return;
    }
    setActiveTab(tab);
  };

  // Direct Wallet Balance Adjustment by Admin
  const handleAdjustUserBalance = (userId: string, amountChange: number, reason: string) => {
    setUsers((prev) =>
      prev.map((u) =>
        u.id === userId
          ? { ...u, walletBalancePKR: Math.max(0, u.walletBalancePKR + amountChange) }
          : u
      )
    );

    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setTransactions((prev) => [
      {
        id: `tx-${Date.now()}`,
        userId,
        type: amountChange >= 0 ? 'CREDIT' : 'DEBIT',
        amountPKR: Math.abs(amountChange),
        description: `Admin Adjustment: ${reason}`,
        timestamp: now,
        status: 'COMPLETED',
      },
      ...prev,
    ]);
  };

  // Add Product from Supplier (Daraz-style multi-image, video, active status)
  const handleAddProduct = (newProductData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...newProductData,
      id: `prod-${Date.now()}`,
    };
    setProducts((prev) => [newProduct, ...prev]);
    handleLogAudit(
      'PRODUCT_ADDED',
      `New product "${newProduct.name}" (SKU: ${newProduct.sku}) added to catalog. Wholesale: PKR ${newProduct.supplierCostPKR}`,
      'SUCCESS'
    );
  };

  // Full Product Update by Admin or Supplier
  const handleUpdateProduct = (updatedProduct: Product) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === updatedProduct.id ? updatedProduct : p))
    );
    handleLogAudit(
      'PRODUCT_EDITED',
      `Product "${updatedProduct.name}" (SKU: ${updatedProduct.sku}) updated. Wholesale: PKR ${updatedProduct.supplierCostPKR}, Stock: ${updatedProduct.stock}, Active: ${updatedProduct.isActive ? 'Yes' : 'No'}`,
      'SUCCESS'
    );
  };

  // Delete Product from Catalog
  const handleDeleteProduct = (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    handleLogAudit(
      'PRODUCT_DELETED',
      `Product "${prod?.name || productId}" removed from catalog.`,
      'WARNING'
    );
  };

  // Full Order Update by Admin
  const handleUpdateOrder = (updatedOrder: Order) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === updatedOrder.id ? updatedOrder : o))
    );
    handleLogAudit(
      'ORDER_EDITED',
      `Order #${updatedOrder.orderNumber} edited by Admin. Status: ${updatedOrder.status}, Customer: ${updatedOrder.customerName}, Tracking: ${updatedOrder.trackingNumber || 'N/A'}`,
      'SUCCESS'
    );
  };

  // Full User Account Update by Admin
  const handleUpdateUser = (updatedUser: User) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );
    if (currentUser.id === updatedUser.id) {
      setCurrentUser(updatedUser);
    }
    handleLogAudit(
      'USER_ACCOUNT_EDITED',
      `User ${updatedUser.name} (${updatedUser.email}, Role: ${updatedUser.role}) profile updated.`,
      'SUCCESS'
    );
  };

  // Toggle Product Active / Inactive Status
  const handleToggleProductActive = (productId: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, isActive: !p.isActive } : p))
    );
  };

  // Update Stock
  const handleUpdateStock = (productId: string, newStock: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock: newStock } : p))
    );
  };

  // Update Supplier Cost
  const handleUpdateCost = (productId: string, newCost: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, supplierCostPKR: newCost } : p))
    );
  };

  // Execute Reseller Customer Order with Exact Deductions (30 Rs processing + delivery + 2% platform)
  const executeCreateSingleOrder = (
    {
      product,
      sellingPrice,
      customerName,
      customerPhone,
      customerCity,
      customerAddress,
    }: {
      product: Product;
      sellingPrice: number;
      customerName: string;
      customerPhone?: string;
      customerCity?: string;
      customerAddress?: string;
    },
    userToUse: User
  ) => {
    const shippingCost = profitGuardConfig.defaultShippingCostPKR;
    const processingFee = profitGuardConfig.processingFeePKR ?? 30;
    const platformFeePct = profitGuardConfig.platformFeePct ?? 2.0;

    // Evaluate with Profit Guard
    const evaluation = evaluateOrderFinancials(
      {
        sellingPricePKR: sellingPrice,
        supplierCostPKR: product.supplierCostPKR,
        shippingCostPKR: shippingCost,
        processingFeePKR: processingFee,
        platformFeePct: platformFeePct,
      },
      profitGuardConfig
    );

    const platformFee = evaluation.financials.platformFeePKR;
    const resellerCommission = evaluation.financials.resellerNetProfitPKR;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber: `YM-${Math.floor(10000 + Math.random() * 90000)}`,
      customerName: customerName || 'Direct Reseller Customer',
      customerPhone: customerPhone || '+92 301 5566778',
      customerCity: customerCity || 'Lahore',
      customerAddress: customerAddress || 'Gulberg III, Main Boulevard, Lahore, Pakistan',
      items: [
        {
          productId: product.id,
          name: product.name,
          sku: product.sku,
          image: product.image,
          qty: 1,
          supplierCostPKR: product.supplierCostPKR,
          sellingPricePKR: sellingPrice,
        },
      ],
      sellingPricePKR: sellingPrice,
      supplierCostPKR: product.supplierCostPKR,
      shippingCostPKR: shippingCost,
      processingFeePKR: processingFee,
      gatewayFeePKR: 0,
      resellerCommissionPKR: resellerCommission,
      platformFeePKR: platformFee,
      netProfitPKR: resellerCommission,
      profitMarginPct: evaluation.financials.profitMarginPct,
      status: 'PENDING_VERIFICATION',
      codRisk: 'LOW',
      codOtpVerified: false,
      profitGuardApproved: evaluation.approved,
      profitGuardReason: evaluation.reason,
      createdAt: new Date().toISOString(),
      resellerId: userToUse.role === 'RESELLER' ? userToUse.id : 'usr-2',
      resellerName: userToUse.role === 'RESELLER' ? userToUse.name : 'Pro Reseller',
      supplierId: product.supplierId,
      supplierName: product.supplierName,
      syncedStore: 'Direct Reseller Order',
      messages: [
        {
          id: `msg-${Date.now()}`,
          senderRole: 'PLATFORM',
          senderName: 'Profit Guard™ Engine',
          text: `Order registered with selling price PKR ${sellingPrice.toLocaleString()}. Supplier Cost: PKR ${product.supplierCostPKR.toLocaleString()}, Processing: PKR ${processingFee}, Courier: PKR ${shippingCost}, Platform Take (2%): PKR ${platformFee}. Reseller Payout: PKR ${resellerCommission.toLocaleString()}. Status: ${
            evaluation.approved ? 'APPROVED & READY FOR VERIFICATION' : 'BLOCKED DUE TO DEFICIT'
          }`,
          timestamp: new Date().toISOString(),
        },
      ],
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Debit Flat 30 Rs Processing Fee & Escrow from Reseller Wallet or track
    if (evaluation.approved) {
      setTransactions((prev) => [
        {
          id: `tx-${Date.now()}`,
          userId: userToUse.id,
          type: 'DEBIT',
          amountPKR: processingFee,
          description: `Flat Processing Fee for Order ${newOrder.orderNumber}`,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          status: 'COMPLETED',
          refOrderId: newOrder.id,
        },
        ...prev,
      ]);
    }
  };

  // Place Reseller Customer Order with Registration Enforcement
  const handlePlaceOrder = (orderData: {
    product: Product;
    sellingPrice: number;
    customerName: string;
    customerPhone?: string;
    customerCity?: string;
    customerAddress?: string;
  }) => {
    // ENFORCE: Any guest/unregistered visitor can freely browse, but must register to place orders
    if (!isRegisteredUser(currentUser)) {
      setPendingSingleOrder(orderData);
      setIsRegistrationRequiredModalOpen(true);
      return;
    }
    executeCreateSingleOrder(orderData, currentUser);
  };

  // Order Lifecycle Handlers
  const handleVerifyCod = (orderId: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'COD_CONFIRMED',
              codOtpVerified: true,
              messages: [
                ...o.messages,
                {
                  id: `msg-${Date.now()}`,
                  senderRole: 'PLATFORM',
                  senderName: 'System Verification',
                  text: 'Customer OTP verified successfully. Order confirmed for warehouse dispatch.',
                  timestamp: new Date().toISOString(),
                },
              ],
            }
          : o
      )
    );
  };

  const handleDispatchOrder = (orderId: string, courierName: string, trackingNumber: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'DISPATCHED',
              courierName,
              trackingNumber,
              messages: [
                ...o.messages,
                {
                  id: `msg-${Date.now()}`,
                  senderRole: 'SUPPLIER',
                  senderName: 'Warehouse Fulfilled',
                  text: `Order packed & dispatched via ${courierName}. Tracking #${trackingNumber}.`,
                  timestamp: new Date().toISOString(),
                },
              ],
            }
          : o
      )
    );
  };

  const handleDeliverOrder = (orderId: string) => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return;

    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'DELIVERED',
              messages: [
                ...o.messages,
                {
                  id: `msg-${Date.now()}`,
                  senderRole: 'PLATFORM',
                  senderName: 'Courier Payout Clearance',
                  text: `COD collected successfully. Supplier escrow (PKR ${o.supplierCostPKR.toLocaleString()}) and Reseller profit (PKR ${o.resellerCommissionPKR.toLocaleString()}) credited to respective wallets.`,
                  timestamp: new Date().toISOString(),
                },
              ],
            }
          : o
      )
    );

    // Credit Reseller Wallet with exact net commission
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === targetOrder.resellerId) {
          return {
            ...u,
            walletBalancePKR: u.walletBalancePKR + targetOrder.resellerCommissionPKR,
          };
        }
        if (u.id === targetOrder.supplierId) {
          return {
            ...u,
            walletBalancePKR: u.walletBalancePKR + targetOrder.supplierCostPKR,
          };
        }
        return u;
      })
    );

    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setTransactions((prev) => [
      {
        id: `tx-${Date.now()}-res`,
        userId: targetOrder.resellerId,
        type: 'CREDIT',
        amountPKR: targetOrder.resellerCommissionPKR,
        description: `Net Profit Commission for Order ${targetOrder.orderNumber}`,
        timestamp: now,
        status: 'COMPLETED',
        refOrderId: targetOrder.id,
      },
      {
        id: `tx-${Date.now()}-sup`,
        userId: targetOrder.supplierId,
        type: 'CREDIT',
        amountPKR: targetOrder.supplierCostPKR,
        description: `Supplier Wholesale Escrow Release for Order ${targetOrder.orderNumber}`,
        timestamp: now,
        status: 'COMPLETED',
        refOrderId: targetOrder.id,
      },
      ...prev,
    ]);
  };

  const handleCancelOrder = (orderId: string, reason: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'CANCELLED',
              messages: [
                ...o.messages,
                {
                  id: `msg-${Date.now()}`,
                  senderRole: currentUser.role as any,
                  senderName: currentUser.name,
                  text: `Order Cancelled: ${reason}`,
                  timestamp: new Date().toISOString(),
                },
              ],
            }
          : o
      )
    );
  };

  const handleSendMessage = (orderId: string, text: string) => {
    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderRole: currentUser.role,
      senderName: currentUser.name,
      text,
      timestamp: new Date().toISOString(),
    };

    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, messages: [...o.messages, newMessage] } : o))
    );
  };

  const handlePushToStore = (product: Product, storePlatform: string, markupPrice: number) => {
    alert(
      `Product "${product.name}" successfully pushed to your ${storePlatform} store at PKR ${markupPrice.toLocaleString()}!`
    );
  };

  const handleAddFunds = (amount: number) => {
    setUsers((prev) =>
      prev.map((u) =>
        u.id === currentUser.id ? { ...u, walletBalancePKR: u.walletBalancePKR + amount } : u
      )
    );
    setCurrentUser((prev) => ({ ...prev, walletBalancePKR: prev.walletBalancePKR + amount }));
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setTransactions((prev) => [
      {
        id: `tx-${Date.now()}`,
        userId: currentUser.id,
        type: 'CREDIT',
        amountPKR: amount,
        description: 'Instant EasyPaisa / JazzCash Top-up',
        timestamp: now,
        status: 'COMPLETED',
      },
      ...prev,
    ]);
  };

  const handleWithdrawFunds = (amount: number, bankDetails: string) => {
    setUsers((prev) =>
      prev.map((u) =>
        u.id === currentUser.id ? { ...u, walletBalancePKR: u.walletBalancePKR - amount } : u
      )
    );
    setCurrentUser((prev) => ({ ...prev, walletBalancePKR: prev.walletBalancePKR - amount }));
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setTransactions((prev) => [
      {
        id: `tx-${Date.now()}`,
        userId: currentUser.id,
        type: 'DEBIT',
        amountPKR: amount,
        description: `Bank Withdrawal Payout to ${bankDetails}`,
        timestamp: now,
        status: 'COMPLETED',
      },
      ...prev,
    ]);
  };

  // Verified Store Registration Handler (Manufacturer & Reseller)
  const handleVerifiedRegister = (data: VerifiedRegistrationData) => {
    const newStoreId = `store-${Date.now()}`;
    const newStore: Store = {
      id: newStoreId,
      name: data.businessName,
      slug: data.businessName.toLowerCase().replace(/[^a-z0-9]/g, '-'),
      logo: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=150&auto=format&fit=crop&q=80',
      ownerId: currentUser.id,
      ownerType: data.role === 'MANUFACTURER' || data.role === 'SUPPLIER' ? 'SUPPLIER' : 'RESELLER',
      city: data.city,
      rating: 5.0,
      totalOrders: 0,
      deliveryRating: '⚡ 2-3 Days Fast Delivery (100% On-Time)',
      responseTime: '< 15 mins',
      description: `${data.businessAddress || data.warehouseAddress} - Fully Verified under NTN: ${data.ntn || 'N/A'} & CNIC: ${data.cnic}`,
      isVerified: true,
      categories: ['Wholesale Direct', 'Verified Factory Sourced'],
      verifiedDetails: data,
    };

    setAllStores((prev) => [newStore, ...prev]);

    // Upgrade User Profile & Switch role
    const updatedUser: User = {
      ...currentUser,
      companyName: data.businessName,
      role: data.role === 'MANUFACTURER' || data.role === 'SUPPLIER' ? 'SUPPLIER' : 'RESELLER',
      phone: data.phone,
    };
    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));

    // Switch view to their brand new store
    setSelectedStoreForView(newStore);
    setActiveTab('store-front');

    handleLogAudit(
      'STORE_VERIFICATION_REGISTERED',
      `Registered fully verified ${data.role} store "${data.businessName}" under NTN ${data.ntn}`,
      'SUCCESS'
    );
  };

  // Product Listing Handler (with multi-images, optional video, store assignment)
  const handleListProduct = (newProduct: Product) => {
    setProducts((prev) => [newProduct, ...prev]);
    handleLogAudit(
      'PRODUCT_LISTED',
      `Listed new product "${newProduct.name}" (${newProduct.sku}) in store "${newProduct.storeName || 'Default Store'}"`,
      'SUCCESS'
    );
  };

  // Bulk CSV / Excel Import Handler
  const handleBulkImport = (importedProducts: Product[]) => {
    setProducts((prev) => [...importedProducts, ...prev]);
    handleLogAudit(
      'BULK_PRODUCTS_IMPORTED',
      `Batch imported ${importedProducts.length} wholesale products from CSV into catalog`,
      'SUCCESS'
    );
  };

  // Store Front Navigation Handler
  const handleOpenStoreFront = (storeId: string) => {
    const store = allStores.find((s) => s.id === storeId) || allStores[0];
    if (store) {
      setSelectedStoreForView(store);
      setActiveTab('store-front');
    }
  };

  // Execute Multi-Product Store Consolidated Order Handler
  const executeCreateMultiOrder = (
    store: Store,
    items: { product: Product; quantity: number }[],
    totalAmount: number,
    customerDetails: {
      customerName: string;
      customerPhone: string;
      customerCity: string;
      customerAddress: string;
    },
    userToUse: User,
    deliveryCharges?: number,
    totalWeightKg?: number
  ) => {
    const orderNumber = `ORD-MULTI-${Date.now().toString().slice(-6)}`;
    const totalSupplierCost = items.reduce(
      (sum, item) => sum + item.product.supplierCostPKR * item.quantity,
      0
    );
    const totalSellingPrice = items.reduce(
      (sum, item) => sum + item.product.recSellingPricePKR * item.quantity,
      0
    );

    const shippingCostPKR = deliveryCharges ?? 200;
    const processingFeePKR = profitGuardConfig.processingFeePKR ?? 30;
    const platformFeePKR = Math.round(totalSellingPrice * ((profitGuardConfig.platformFeePct ?? 2.0) / 100));
    const resellerCommissionPKR = Math.max(0, totalSellingPrice - totalSupplierCost - processingFeePKR - platformFeePKR);

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      customerName: customerDetails.customerName,
      customerPhone: customerDetails.customerPhone,
      customerCity: customerDetails.customerCity,
      customerAddress: customerDetails.customerAddress,
      items: items.map((i) => ({
        productId: i.product.id,
        name: i.product.name,
        productName: i.product.name,
        sku: i.product.sku,
        image: i.product.image || '',
        qty: i.quantity,
        supplierCostPKR: i.product.supplierCostPKR,
        sellingPricePKR: i.product.recSellingPricePKR,
      })),
      sellingPricePKR: totalSellingPrice,
      supplierCostPKR: totalSupplierCost,
      shippingCostPKR, // Consolidated flat delivery for multiple items from same store by weight!
      processingFeePKR,
      gatewayFeePKR: 0,
      resellerCommissionPKR: resellerCommissionPKR,
      platformFeePKR: platformFeePKR,
      netProfitPKR: resellerCommissionPKR,
      profitMarginPct: Math.round(((totalSellingPrice - totalSupplierCost) / totalSellingPrice) * 100),
      status: 'PENDING_VERIFICATION',
      codRisk: 'LOW',
      codOtpVerified: false,
      profitGuardApproved: true,
      profitGuardReason: `Consolidated parcel order from store "${store.name}". Weight: ${totalWeightKg || 1.0} kg. Delivery Fee: PKR ${shippingCostPKR}. Platform clearance: 2%.`,
      createdAt: new Date().toISOString(),
      resellerId: userToUse.role === 'RESELLER' ? userToUse.id : 'usr-2',
      resellerName: userToUse.role === 'RESELLER' ? userToUse.name : 'Pro Reseller',
      supplierId: store.ownerId || store.id,
      supplierName: store.name,
      syncedStore: store.name,
      messages: [
        {
          id: `msg-${Date.now()}`,
          senderRole: 'PLATFORM',
          senderName: 'Consolidated Store Order',
          text: `Consolidated parcel order placed for ${items.length} products (Total Weight: ${totalWeightKg || 1.0} kg) from store "${store.name}". Weight-based delivery fee: PKR ${shippingCostPKR}. Customer COD Total: PKR ${totalAmount.toLocaleString()} (Platform Fee 2%: PKR ${platformFeePKR.toLocaleString()}).`,
          timestamp: new Date().toISOString(),
        },
      ],
    };

    setOrders((prev) => [newOrder, ...prev]);
    setActiveTab('orders');
  };

  // Multi-Product Store Consolidated Order Handler with Registration Enforcement
  const handlePlaceMultiOrder = (
    store: Store,
    items: { product: Product; quantity: number }[],
    totalAmount: number,
    customerDetails: {
      customerName: string;
      customerPhone: string;
      customerCity: string;
      customerAddress: string;
    },
    deliveryCharges?: number,
    totalWeightKg?: number
  ) => {
    // ENFORCE: Any guest/unregistered visitor can freely browse, but must register to place orders
    if (!isRegisteredUser(currentUser)) {
      setPendingMultiOrder({
        store,
        items,
        totalAmount,
        customerDetails,
        deliveryCharges,
        totalWeightKg,
      });
      setIsRegistrationRequiredModalOpen(true);
      return;
    }
    executeCreateMultiOrder(store, items, totalAmount, customerDetails, currentUser, deliveryCharges, totalWeightKg);
  };

  // Checkout Handler for MultiProductCartDrawer
  const handleCheckoutOrder = (orderPayload: {
    items: { product: Product; quantity: number }[];
    totalAmount: number;
    customerDetails: {
      customerName: string;
      customerPhone: string;
      customerCity: string;
      customerAddress: string;
    };
    deliveryCharges: number;
    totalWeightKg: number;
  }) => {
    const firstProduct = orderPayload.items[0]?.product;
    const targetStore =
      allStores.find((s) => s.ownerId === firstProduct?.supplierId || s.id === firstProduct?.storeId) ||
      allStores[0];

    if (!isRegisteredUser(currentUser)) {
      setPendingMultiOrder({
        store: targetStore,
        items: orderPayload.items,
        totalAmount: orderPayload.totalAmount,
        customerDetails: orderPayload.customerDetails,
        deliveryCharges: orderPayload.deliveryCharges,
        totalWeightKg: orderPayload.totalWeightKg,
      });
      setIsRegistrationRequiredModalOpen(true);
      return;
    }

    executeCreateMultiOrder(
      targetStore,
      orderPayload.items,
      orderPayload.totalAmount,
      orderPayload.customerDetails,
      currentUser,
      orderPayload.deliveryCharges,
      orderPayload.totalWeightKg
    );
  };

  // Callback when a guest finishes registration or switches to a registered user
  const handleRegistrationCompleted = (registeredUser: User) => {
    setCurrentUser(registeredUser);
    setUsers((prev) => {
      const exists = prev.some((u) => u.id === registeredUser.id);
      return exists ? prev.map((u) => (u.id === registeredUser.id ? registeredUser : u)) : [registeredUser, ...prev];
    });
    setIsRegistrationRequiredModalOpen(false);

    // Auto-resume pending order placement if one was blocked!
    if (pendingSingleOrder) {
      executeCreateSingleOrder(pendingSingleOrder, registeredUser);
      setPendingSingleOrder(null);
    } else if (pendingMultiOrder) {
      executeCreateMultiOrder(
        pendingMultiOrder.store,
        pendingMultiOrder.items,
        pendingMultiOrder.totalAmount,
        pendingMultiOrder.customerDetails,
        registeredUser,
        pendingMultiOrder.deliveryCharges,
        pendingMultiOrder.totalWeightKg
      );
      setPendingMultiOrder(null);
    }
  };

  const pendingOrdersCount = orders.filter((o) => o.status === 'PENDING_VERIFICATION').length;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans">
      {/* Permanent Left Sidebar (matching uploaded screenshot) */}
      <YourMartSidebar
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        pendingOrdersCount={pendingOrdersCount}
        cartCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
        currentUser={currentUser}
        isAdminAuthenticated={isAdminAuthenticated}
        onOpenFunctionsDrawer={() => setIsFunctionsDrawerOpen(true)}
        onOpenUpgradeModal={() => setIsVerifiedRegistrationOpen(true)}
        onOpenStoreSyncModal={() => setIsStoreSyncModalOpen(true)}
        onOpenWalletModal={() => setIsWalletModalOpen(true)}
        onOpenCart={() => setIsCartDrawerOpen(true)}
        onOpenHelplinesModal={() => setIsHelplinesModalOpen(true)}
        onOpenAdminAuth={() => setIsAdminAuthModalOpen(true)}
        onLockAdmin={handleLockAdmin}
        onOpenProfitGuardModal={() => setIsProfitGuardModalOpen(true)}
        onOpenAIDispatch={() => setIsAIDispatchModalOpen(true)}
        onOpenProductListing={() => setIsProductListingOpen(true)}
        onOpenBulkImport={() => setIsBulkImportOpen(true)}
        onOpenPoliciesModal={() => setIsPoliciesModalOpen(true)}
      />

      {/* Main Area (pushed right for sidebar on lg screens) */}
      <div className="lg:pl-64 flex-1 flex flex-col min-w-0 bg-[#F8FAFC]">
        {/* Top Bar with Hot Wholesale Deals ticker and user/wallet/cart pills */}
        <YourMartTopBar
          currentUser={currentUser}
          cartCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
          onOpenCart={() => setIsCartDrawerOpen(true)}
          onOpenWallet={() => setIsWalletModalOpen(true)}
          onOpenPlanDetails={() => setIsVerifiedRegistrationOpen(true)}
          onOpenProfile={() => setIsProfileSettingsOpen(true)}
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(true)}
          onExploreSourcing={() => handleSelectTab('catalog')}
        />

        {/* Main App Body */}
        <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-6 sm:px-6">
          {activeTab === 'dashboard' && (
            <FrontPageDashboard
              orders={orders}
              products={products}
              currentUser={currentUser}
              onNavigateTab={handleSelectTab}
              onOpenAddProduct={() => setIsProductListingOpen(true)}
              onOpenBulkImport={() => setIsBulkImportOpen(true)}
              onOpenPolicies={() => setIsPoliciesModalOpen(true)}
              onOpenAIDispatch={() => setIsAIDispatchModalOpen(true)}
              onOpenProfileSettings={() => setIsProfileSettingsOpen(true)}
              onOpenStoreSyncModal={() => setIsStoreSyncModalOpen(true)}
              onOpenHelplinesModal={() => setIsHelplinesModalOpen(true)}
            />
          )}

        {activeTab === 'catalog' && (
          <ResellerPortal
            currentUser={currentUser}
            products={products}
            profitGuardConfig={profitGuardConfig}
            bankTransferDetails={bankTransferDetails}
            stores={stores}
            onPlaceSampleOrder={(p, price, customerDetails) =>
              handlePlaceOrder({
                product: p,
                sellingPrice: price,
                customerName: customerDetails.customerName,
                customerPhone: customerDetails.customerPhone,
                customerCity: customerDetails.customerCity,
                customerAddress: customerDetails.customerAddress,
              })
            }
            onPushToStore={handlePushToStore}
            onOpenStoreSyncModal={() => setIsStoreSyncModalOpen(true)}
            onOpenStoreFront={handleOpenStoreFront}
            onOpenVerifiedRegistration={() => setIsVerifiedRegistrationOpen(true)}
            onAddToCart={handleAddToCart}
          />
        )}

        {activeTab === 'stores-directory' && (
          <StoresDirectoryView
            stores={allStores}
            products={products}
            onSelectStore={(store) => {
              setSelectedStoreForView(store);
              setActiveTab('store-front');
            }}
            onOpenVerifiedRegistration={() => setIsVerifiedRegistrationOpen(true)}
          />
        )}

        {activeTab === 'store-front' && (
          <StoreFrontView
            store={selectedStoreForView || allStores[0]}
            allProducts={products}
            currentUser={currentUser}
            profitGuardConfig={profitGuardConfig}
            bankTransferDetails={bankTransferDetails}
            onBack={() => setActiveTab('stores-directory')}
            onSelectProduct={() => {}}
            onPlaceMultiOrder={(items, customerDetails, totalAmountPKR) => {
              handlePlaceMultiOrder(
                selectedStoreForView || allStores[0],
                items.map((i) => ({ product: i.product, quantity: i.quantity })),
                totalAmountPKR,
                customerDetails
              );
            }}
          />
        )}

        {activeTab === 'orders' && (
          <OrdersManager
            currentUser={currentUser}
            orders={orders}
            onVerifyCod={handleVerifyCod}
            onDispatchOrder={handleDispatchOrder}
            onDeliverOrder={handleDeliverOrder}
            onCancelOrder={handleCancelOrder}
            onSendMessage={handleSendMessage}
          />
        )}

        {activeTab === 'admin-hq' && (
          <AdminDashboard
            profitGuardConfig={profitGuardConfig}
            onUpdateConfig={setProfitGuardConfig}
            orders={orders}
            onUpdateOrder={handleUpdateOrder}
            products={products}
            onUpdateProduct={handleUpdateProduct}
            onAddProduct={handleAddProduct}
            onDeleteProduct={handleDeleteProduct}
            users={users}
            onUpdateUser={handleUpdateUser}
            transactions={transactions}
            onOpenProfitGuardModal={() => setIsProfitGuardModalOpen(true)}
            bankTransferDetails={bankTransferDetails}
            onUpdateBankDetails={(newDetails) => {
              setBankTransferDetails(newDetails);
              localStorage.setItem('ym_bank_transfer_details', JSON.stringify(newDetails));
            }}
            securityConfig={securityConfig}
            onUpdateSecurityConfig={handleUpdateSecurityConfig}
            auditLogs={auditLogs}
            onLogAudit={handleLogAudit}
            onLockAdmin={handleLockAdmin}
            onAdjustUserBalance={handleAdjustUserBalance}
            helplinesConfig={helplinesConfig}
            onUpdateHelplinesConfig={handleUpdateHelplinesConfig}
          />
        )}

        {activeTab === 'supplier-hub' && (
          <SupplierPortal
            currentUser={currentUser}
            products={products}
            orders={orders}
            onAddProduct={handleAddProduct}
            onUpdateStock={handleUpdateStock}
            onUpdateCost={handleUpdateCost}
            onToggleActive={handleToggleProductActive}
          />
        )}

        {activeTab === 'daraz-calculator' && (
          <DarazCalculator
            products={products}
            onSelectProductForOrder={(product, price) => {
              handlePlaceOrder({
                product,
                sellingPrice: price,
                customerName: 'Daraz Customer',
                customerPhone: '0300-1234567',
                customerCity: 'Lahore',
                customerAddress: 'Daraz Hub Transit',
              });
              setActiveTab('orders');
            }}
          />
        )}

        {activeTab === 'checkout-demo' && (
          <CustomerCheckoutView
            products={products}
            onPlaceOrder={(orderData) =>
              handlePlaceOrder({
                product: orderData.product,
                sellingPrice: orderData.sellingPrice,
                customerName: orderData.customerName,
                customerPhone: orderData.customerPhone,
                customerCity: orderData.customerCity,
                customerAddress: orderData.customerAddress,
              })
            }
          />
        )}
      </main>

      {/* Admin Security Authentication Gateway Modal */}
      <AdminAuthModal
        isOpen={isAdminAuthModalOpen}
        onClose={() => setIsAdminAuthModalOpen(false)}
        securityConfig={securityConfig}
        onAuthenticateSuccess={handleAuthenticateAdminSuccess}
        onLogAudit={handleLogAudit}
      />

      {/* Global Modals */}
      <ProfitGuardModal
        isOpen={isProfitGuardModalOpen}
        onClose={() => setIsProfitGuardModalOpen(false)}
        config={profitGuardConfig}
      />

      <StoreSyncModal
        isOpen={isStoreSyncModalOpen}
        onClose={() => setIsStoreSyncModalOpen(false)}
        stores={stores}
        onToggleStoreConnection={(id) =>
          setStores((prev) =>
            prev.map((s) => (s.id === id ? { ...s, connected: !s.connected } : s))
          )
        }
        onSyncNow={(id) =>
          setStores((prev) =>
            prev.map((s) => (s.id === id ? { ...s, lastSync: 'Just now' } : s))
          )
        }
      />

      <WalletModal
        isOpen={isWalletModalOpen}
        onClose={() => setIsWalletModalOpen(false)}
        currentUser={currentUser}
        transactions={transactions}
        onAddFunds={handleAddFunds}
        onWithdrawFunds={handleWithdrawFunds}
      />

      {/* Helplines (Buyers, Resellers, Manufacturers) Support Modal */}
      <HelplinesModal
        isOpen={isHelplinesModalOpen}
        onClose={() => setIsHelplinesModalOpen(false)}
        helplinesConfig={helplinesConfig}
        onUpdateHelplinesConfig={handleUpdateHelplinesConfig}
        isAdminAuthenticated={isAdminAuthenticated}
        onOpenAdminAuth={() => setIsAdminAuthModalOpen(true)}
        onLogAudit={handleLogAudit}
      />

      {/* Verified Registration Modal (Manufacturers & Resellers) */}
      <VerifiedRegistrationModal
        isOpen={isVerifiedRegistrationOpen}
        onClose={() => setIsVerifiedRegistrationOpen(false)}
        currentUser={currentUser}
        onRegistrationSuccess={handleVerifiedRegister}
      />

      {/* Product Listing Modal (Multi-Images & Optional Video) */}
      <ProductListingModal
        isOpen={isProductListingOpen}
        onClose={() => setIsProductListingOpen(false)}
        currentUser={currentUser}
        stores={allStores}
        onProductCreated={handleListProduct}
      />

      {/* Bulk CSV / Excel Import Modal */}
      <BulkImportModal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        currentUser={currentUser}
        stores={allStores}
        onImportSuccess={handleBulkImport}
      />

      {/* Registered User Profile & Settings Modal */}
      <ProfileSettingsModal
        isOpen={isProfileSettingsOpen}
        onClose={() => setIsProfileSettingsOpen(false)}
        currentUser={currentUser}
        onUpdateUser={handleUpdateUserProfile}
      />

      {/* Platform Policies & Software Usage Rules (2% Commission) Modal */}
      <PlatformPoliciesModal
        isOpen={isPoliciesModalOpen}
        onClose={() => setIsPoliciesModalOpen(false)}
        currentUser={currentUser}
      />

      {/* AI Customer Query Auto-Dispatch Engine Modal */}
      <AIDispatchModal
        isOpen={isAIDispatchModalOpen}
        onClose={() => setIsAIDispatchModalOpen(false)}
        currentUser={currentUser}
      />

      {/* 3-Line Centralized Dashboard & All Functions Drawer */}
      <FunctionsDashboardDrawer
        isOpen={isFunctionsDrawerOpen}
        onClose={() => setIsFunctionsDrawerOpen(false)}
        currentUser={currentUser}
        allUsers={users}
        onSelectUser={handleSelectUser}
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        profitGuardConfig={profitGuardConfig}
        stores={stores}
        pendingOrdersCount={pendingOrdersCount}
        isAdminAuthenticated={isAdminAuthenticated}
        onOpenProfitGuardModal={() => setIsProfitGuardModalOpen(true)}
        onOpenStoreSyncModal={() => setIsStoreSyncModalOpen(true)}
        onOpenWalletModal={() => setIsWalletModalOpen(true)}
        onOpenHelplinesModal={() => setIsHelplinesModalOpen(true)}
        onOpenProfileSettings={() => setIsProfileSettingsOpen(true)}
        onOpenPoliciesModal={() => setIsPoliciesModalOpen(true)}
        onOpenAIDispatch={() => setIsAIDispatchModalOpen(true)}
        onOpenVerifiedRegistration={() => setIsVerifiedRegistrationOpen(true)}
        onOpenProductListing={() => setIsProductListingOpen(true)}
        onOpenBulkImport={() => setIsBulkImportOpen(true)}
        onOpenAdminAuth={() => setIsAdminAuthModalOpen(true)}
        onLockAdmin={handleLockAdmin}
      />

      {/* Registration Required Interception Modal for Guest Orders */}
      <RegistrationRequiredModal
        isOpen={isRegistrationRequiredModalOpen}
        onClose={() => {
          setIsRegistrationRequiredModalOpen(false);
          setPendingSingleOrder(null);
          setPendingMultiOrder(null);
        }}
        currentUser={currentUser}
        allUsers={users}
        onSelectRegisteredUser={handleRegistrationCompleted}
        onRegistrationSuccess={handleRegistrationCompleted}
      />

      {/* Multi-Product Consolidated Cart Drawer (Single Store, Weight-Based Delivery Calculation) */}
      <MultiProductCartDrawer
        isOpen={isCartDrawerOpen}
        onClose={() => setIsCartDrawerOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        profitGuardConfig={profitGuardConfig}
        currentUser={currentUser}
        onCheckoutOrder={handleCheckoutOrder}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-4 text-xs text-slate-500 text-center">
        <div className="mx-auto max-w-7xl px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>YourMart Global • Wholesale B2B, Reseller Sourcing & COD Payout Engine</span>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setIsPoliciesModalOpen(true)}
              className="text-slate-400 hover:text-emerald-400 font-medium transition flex items-center gap-1"
              title="Platform Policies & 2% Standard"
            >
              <span>📜 Policies (2% Fee)</span>
            </button>
            <span className="text-slate-700 hidden sm:inline">•</span>
            <button
              onClick={() => setIsAIDispatchModalOpen(true)}
              className="text-indigo-400 hover:text-indigo-300 font-medium transition flex items-center gap-1"
              title="AI Customer Auto-Reply Engine"
            >
              <span>🤖 AI Dispatch</span>
            </button>
            <span className="text-slate-700 hidden sm:inline">•</span>
            <button
              onClick={() => setIsProfileSettingsOpen(true)}
              className="text-slate-400 hover:text-slate-200 font-medium transition flex items-center gap-1"
              title="Profile & Settings"
            >
              <span>⚙️ Profile Settings</span>
            </button>
            <span className="text-slate-700 hidden sm:inline">•</span>
            <button
              onClick={() => setIsHelplinesModalOpen(true)}
              className="text-emerald-400 hover:text-emerald-300 font-semibold underline flex items-center gap-1 transition"
            >
              <span>📞 Helplines</span>
            </button>
            <span className="font-mono text-[11px] text-slate-500 hidden lg:inline">
              Rs. 30 Processing • 2% Platform Clearance
            </span>
            {/* Discreet Creator Access Link */}
            <button
              onClick={() => {
                if (isAdminAuthenticated) {
                  handleSelectTab('admin-hq');
                } else {
                  setIsAdminAuthModalOpen(true);
                }
              }}
              className="text-slate-600 hover:text-slate-400 transition ml-1"
              title="Software Creator Access (Alt+A)"
            >
              🔒
            </button>
          </div>
        </div>
      </footer>
      </div>
    </div>
  );
}
